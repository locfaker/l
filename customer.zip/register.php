<?php
require_once 'config.php';

// Kiểm tra nếu đã đăng nhập thì chuyển hướng về trang chủ
if (isLoggedIn()) {
    if (hasRole('admin')) {
        redirect('admin/');
    } elseif (hasRole('driver')) {
        redirect('driver/');
    } else {
        redirect('customer/');
    }
}

// Xử lý đăng ký
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? 'customer';
    
    // Validate input
    $errors = [];
    
    if (empty($name)) {
        $errors[] = "Họ tên không được để trống";
    }
    
    if (empty($email)) {
        $errors[] = "Email không được để trống";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email không hợp lệ";
    }
    
    if (empty($password)) {
        $errors[] = "Mật khẩu không được để trống";
    } elseif (strlen($password) < 6) {
        $errors[] = "Mật khẩu phải có ít nhất 6 ký tự";
    }
    
    if ($password !== $confirm_password) {
        $errors[] = "Mật khẩu xác nhận không khớp";
    }
    
    // Trong ứng dụng thực tế, bạn sẽ kiểm tra xem email đã tồn tại trong database chưa
    
    // If no errors, register user
    if (empty($errors)) {
        // Trong ứng dụng thực tế, bạn sẽ lưu thông tin vào database
        // Ở đây chúng ta sẽ giả lập đăng ký thành công
        
        // Đặt thông báo thành công
        $_SESSION['register_success'] = true;
        
        // Chuyển hướng đến trang đăng nhập
        redirect('login.php');
    }
}

include 'header.php';
?>

<div class="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden mt-8">
    <div class="p-6">
        <h2 class="text-2xl font-bold text-center mb-6">Đăng ký tài khoản</h2>
        
        <?php if (!empty($errors)): ?>
            <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-6">
                <ul class="list-disc list-inside">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-4">
                <label for="name" class="block text-gray-700 font-medium mb-2">Họ tên</label>
                <input type="text" id="name" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500" required>
            </div>
            
            <div class="mb-4">
                <label for="email" class="block text-gray-700 font-medium mb-2">Email</label>
                <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500" required>
            </div>
            
            <div class="mb-4">
                <label for="password" class="block text-gray-700 font-medium mb-2">Mật khẩu</label>
                <input type="password" id="password" name="password" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500" required>
            </div>
            
            <div class="mb-4">
                <label for="confirm_password" class="block text-gray-700 font-medium mb-2">Xác nhận mật khẩu</label>
                <input type="password" id="confirm_password" name="confirm_password" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500" required>
            </div>
            
            <div class="mb-6">
                <label for="role" class="block text-gray-700 font-medium mb-2">Đăng ký với vai trò</label>
                <select id="role" name="role" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500">
                    <option value="customer" <?php echo (isset($_POST['role']) && $_POST['role'] === 'customer') ? 'selected' : ''; ?>>Khách hàng</option>
                    <option value="driver" <?php echo (isset($_POST['role']) && $_POST['role'] === 'driver') ? 'selected' : ''; ?>>Tài xế</option>
                </select>
            </div>
            
            <div class="mb-6">
                <button type="submit" class="w-full bg-indigo-600 text-white font-medium py-3 rounded-lg hover:bg-indigo-700 focus:outline-none">
                    Đăng ký
                </button>
            </div>
        </form>
        
        <div class="text-center">
            <p class="text-gray-600">Đã có tài khoản? <a href="login.php" class="text-indigo-600 hover:text-indigo-800">Đăng nhập</a></p>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 