<?php
// Include config file
require_once '../config.php';

// Nếu không đăng nhập hoặc không phải admin thì chuyển hướng về trang đăng nhập
if (!isLoggedIn() || !hasRole('admin')) {
    redirect('login.php');
}

// Include header
include '../header.php';
?>

<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6">Admin Dashboard</h1>

    <!-- Tabs -->
    <div class="mb-6">
        <div class="border-b border-gray-200">
            <nav class="-mb-px flex space-x-8">
                <a href="#" class="border-indigo-500 text-indigo-600 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm" id="tab-orders">
                    Orders
                </a>
                <a href="#" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm" id="tab-drivers">
                    Drivers
                </a>
                <a href="#" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm" id="tab-analytics">
                    Analytics
                </a>
            </nav>
        </div>
    </div>

    <!-- Orders Tab Content -->
    <div id="content-orders" class="tab-content">
        <div class="bg-white shadow-md rounded-lg mb-6">
            <div class="p-6">
                <h2 class="text-xl font-bold mb-4">Active Orders</h2>
                <div class="space-y-4">
                    <?php for ($i = 1; $i <= 3; $i++): ?>
                    <div class="flex justify-between items-center border-b pb-4">
                        <div>
                            <h4 class="font-semibold">Order #<?php echo 1234 + $i; ?></h4>
                            <p class="text-sm text-gray-500">Customer: Jane Doe</p>
                            <p class="text-sm text-gray-500">Status: In Transit</p>
                        </div>
                        <div class="flex space-x-2">
                            <button class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-2 px-4 rounded text-sm">
                                Assign Driver
                            </button>
                            <button class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded text-sm">
                                View Details
                            </button>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Drivers Tab Content -->
    <div id="content-drivers" class="tab-content hidden">
        <div class="bg-white shadow-md rounded-lg mb-6">
            <div class="p-6">
                <h2 class="text-xl font-bold mb-4">Active Drivers</h2>
                <div class="space-y-4">
                    <?php for ($i = 1; $i <= 3; $i++): ?>
                    <div class="flex justify-between items-center border-b pb-4">
                        <div class="flex items-center space-x-4">
                            <div class="w-12 h-12 rounded-full bg-gray-200"></div>
                            <div>
                                <h4 class="font-semibold">Driver <?php echo $i; ?></h4>
                                <p class="text-sm text-gray-500">Status: Active</p>
                            </div>
                        </div>
                        <div>
                            <span class="badge bg-green-600 text-white px-2 py-1 rounded text-xs">Available</span>
                            <button class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-2 px-4 rounded text-sm ml-2">
                                View Profile
                            </button>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Analytics Tab Content -->
    <div id="content-analytics" class="tab-content hidden">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white shadow-md rounded-lg">
                <div class="p-6">
                    <h2 class="text-lg font-bold mb-2">Total Orders</h2>
                    <p class="text-3xl font-bold">156</p>
                    <p class="text-sm text-gray-500">This month</p>
                </div>
            </div>

            <div class="bg-white shadow-md rounded-lg">
                <div class="p-6">
                    <h2 class="text-lg font-bold mb-2">Active Drivers</h2>
                    <p class="text-3xl font-bold">12</p>
                    <p class="text-sm text-gray-500">Currently online</p>
                </div>
            </div>

            <div class="bg-white shadow-md rounded-lg">
                <div class="p-6">
                    <h2 class="text-lg font-bold mb-2">Revenue</h2>
                    <p class="text-3xl font-bold">$2,450</p>
                    <p class="text-sm text-gray-500">This month</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Tab switching functionality
    document.addEventListener('DOMContentLoaded', function() {
        const tabs = document.querySelectorAll('a[id^="tab-"]');
        const contents = document.querySelectorAll('div[id^="content-"]');

        tabs.forEach(tab => {
            tab.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Remove active class from all tabs
                tabs.forEach(t => {
                    t.classList.remove('border-indigo-500', 'text-indigo-600');
                    t.classList.add('border-transparent', 'text-gray-500', 'hover:text-gray-700', 'hover:border-gray-300');
                });
                
                // Add active class to current tab
                this.classList.remove('border-transparent', 'text-gray-500', 'hover:text-gray-700', 'hover:border-gray-300');
                this.classList.add('border-indigo-500', 'text-indigo-600');
                
                // Hide all content
                contents.forEach(content => {
                    content.classList.add('hidden');
                });
                
                // Show corresponding content
                const contentId = 'content-' + this.id.split('-')[1];
                document.getElementById(contentId).classList.remove('hidden');
            });
        });
    });
</script>

<?php include '../footer.php'; ?> 