<?php
// Include config file
require_once '../config.php';

// Nếu không đăng nhập hoặc không phải khách hàng thì chuyển hướng về trang đăng nhập
if (!isLoggedIn() || !hasRole('customer')) {
    redirect('login.php');
}

// Include header
include '../header.php';
?>

<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6">Customer Dashboard</h1>
    
    <!-- Quick Stats -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div class="bg-white shadow-md rounded-lg">
            <div class="p-6">
                <h2 class="text-lg font-bold mb-2">Active Orders</h2>
                <p class="text-3xl font-bold">2</p>
                <p class="text-sm text-gray-500">In progress</p>
            </div>
        </div>

        <div class="bg-white shadow-md rounded-lg">
            <div class="p-6">
                <h2 class="text-lg font-bold mb-2">Completed Orders</h2>
                <p class="text-3xl font-bold">12</p>
                <p class="text-sm text-gray-500">This month</p>
            </div>
        </div>

        <div class="bg-white shadow-md rounded-lg">
            <div class="p-6">
                <h2 class="text-lg font-bold mb-2">Total Spent</h2>
                <p class="text-3xl font-bold">$432</p>
                <p class="text-sm text-gray-500">This month</p>
            </div>
        </div>
    </div>
    
    <!-- Active Orders -->
    <div class="bg-white shadow-md rounded-lg mb-6">
        <div class="p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold">Active Orders</h2>
                <a href="orders.php" class="text-indigo-600 hover:text-indigo-800 text-sm font-medium">View All</a>
            </div>
            
            <div class="space-y-4">
                <!-- Order Item 1 -->
                <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between mb-2">
                        <h3 class="font-semibold">Order #12348</h3>
                        <span class="badge bg-indigo-600 text-white px-2 py-1 rounded text-xs">In Transit</span>
                    </div>
                    <p class="text-sm text-gray-500 mb-2">Estimated delivery: Today, 2:30 PM</p>
                    <div class="flex justify-between items-center mt-4">
                        <div class="text-sm">
                            <span class="text-gray-500">Total: </span>
                            <span class="font-medium">$35.99</span>
                        </div>
                        <button class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded text-sm">
                            Track Order
                        </button>
                    </div>
                </div>
                
                <!-- Order Item 2 -->
                <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between mb-2">
                        <h3 class="font-semibold">Order #12347</h3>
                        <span class="badge bg-amber-500 text-white px-2 py-1 rounded text-xs">Processing</span>
                    </div>
                    <p class="text-sm text-gray-500 mb-2">Estimated delivery: Tomorrow, 10:00 AM</p>
                    <div class="flex justify-between items-center mt-4">
                        <div class="text-sm">
                            <span class="text-gray-500">Total: </span>
                            <span class="font-medium">$24.50</span>
                        </div>
                        <button class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded text-sm">
                            Track Order
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Orders -->
    <div class="bg-white shadow-md rounded-lg">
        <div class="p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold">Recent Orders</h2>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                #<?php echo 12340 + $i; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                March <?php echo $i; ?>, 2024
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="badge bg-green-600 text-white px-2 py-1 rounded text-xs">Delivered</span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                $<?php echo 15 + ($i * 5); ?>.99
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <a href="#" class="text-indigo-600 hover:text-indigo-900">Details</a>
                            </td>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../footer.php'; ?> 