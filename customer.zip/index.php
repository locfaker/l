<?php include 'header.php'; ?>

<div class="text-center mb-8">
    <h1 class="text-4xl font-bold text-gray-800 mb-4">Chào mừng đến với Dreamy Delivery</h1>
    <p class="text-xl text-gray-600 max-w-3xl mx-auto">Giải pháp giao hàng đáng tin cậy cho mọi nhu cầu của bạn</p>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
    <!-- Customer Portal -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-2">Khách hàng</h2>
            <p class="text-gray-600 mb-4">Đặt hàng và theo dõi đơn hàng của bạn</p>
            <a href="customer/" class="block w-full text-center bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded">
                Vào cổng Khách hàng
            </a>
        </div>
    </div>

    <!-- Driver Portal -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-2">Tài xế</h2>
            <p class="text-gray-600 mb-4">Quản lý giao hàng và theo dõi thu nhập</p>
            <a href="driver/" class="block w-full text-center border border-indigo-600 hover:bg-indigo-50 text-indigo-600 font-medium py-2 px-4 rounded">
                Vào cổng Tài xế
            </a>
        </div>
    </div>

    <!-- Admin Portal -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-2">Quản trị viên</h2>
            <p class="text-gray-600 mb-4">Quản lý đơn hàng, tài xế và cài đặt hệ thống</p>
            <a href="admin/" class="block w-full text-center bg-gray-800 hover:bg-gray-900 text-white font-medium py-2 px-4 rounded">
                Vào cổng Quản trị
            </a>
        </div>
    </div>
</div>

<!-- Features -->
<div class="mt-16">
    <h2 class="text-2xl font-bold text-center mb-8">Dịch vụ của chúng tôi</h2>
    
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white p-6 rounded-lg shadow-md">
            <div class="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                <i class="fas fa-truck text-indigo-600 text-xl"></i>
            </div>
            <h3 class="text-lg font-semibold mb-2">Giao hàng nhanh chóng</h3>
            <p class="text-gray-600">Dịch vụ giao hàng nhanh chóng và đúng hẹn trong khu vực nội thành.</p>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow-md">
            <div class="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                <i class="fas fa-map-marked-alt text-indigo-600 text-xl"></i>
            </div>
            <h3 class="text-lg font-semibold mb-2">Theo dõi đơn hàng</h3>
            <p class="text-gray-600">Theo dõi đơn hàng theo thời gian thực với hệ thống định vị GPS.</p>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow-md">
            <div class="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                <i class="fas fa-shield-alt text-indigo-600 text-xl"></i>
            </div>
            <h3 class="text-lg font-semibold mb-2">An toàn & Bảo mật</h3>
            <p class="text-gray-600">Đảm bảo an toàn cho hàng hóa của bạn trong quá trình vận chuyển.</p>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow-md">
            <div class="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                <i class="fas fa-headset text-indigo-600 text-xl"></i>
            </div>
            <h3 class="text-lg font-semibold mb-2">Hỗ trợ 24/7</h3>
            <p class="text-gray-600">Đội ngũ hỗ trợ khách hàng luôn sẵn sàng giúp đỡ bạn 24/7.</p>
        </div>
    </div>
</div>

<!-- CTA -->
<div class="mt-16 bg-indigo-600 text-white p-8 rounded-lg text-center">
    <h2 class="text-2xl font-bold mb-4">Bắt đầu sử dụng dịch vụ ngay hôm nay</h2>
    <p class="mb-6 max-w-2xl mx-auto">Đăng ký tài khoản miễn phí và trải nghiệm dịch vụ giao hàng tốt nhất.</p>
    <a href="register.php" class="inline-block bg-white text-indigo-600 font-semibold py-3 px-6 rounded-md hover:bg-gray-100">
        Đăng ký ngay
    </a>
</div>

<?php include 'footer.php'; ?> 