<?php 
require_once 'config.php';

// Kiểm tra nếu đã đăng nhập thì chuyển hướng về trang chủ
if (isLoggedIn()) {
    if (hasRole('admin')) {
        redirect('admin/');
    } elseif (hasRole('driver')) {
        redirect('driver/');
    } else {
        redirect('customer/');
    }
}

// Xử lý đăng nhập
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Validate input
    $errors = [];
    
    if (empty($email)) {
        $errors[] = "Email không được để trống";
    }
    
    if (empty($password)) {
        $errors[] = "Mật khẩu không được để trống";
    }
    
    // If no errors, attempt login
    if (empty($errors)) {
        // In a real app, you would validate against database
        // For demo, we'll use simple checks
        if ($email === 'admin@example.com' && $password === 'password') {
            $_SESSION['user_id'] = 1;
            $_SESSION['user_name'] = 'Admin User';
            $_SESSION['user_role'] = 'admin';
            redirect('admin/');
        } elseif ($email === 'driver@example.com' && $password === 'password') {
            $_SESSION['user_id'] = 2;
            $_SESSION['user_name'] = 'Driver User';
            $_SESSION['user_role'] = 'driver';
            redirect('driver/');
        } elseif ($email === 'customer@example.com' && $password === 'password') {
            $_SESSION['user_id'] = 3;
            $_SESSION['user_name'] = 'Customer User';
            $_SESSION['user_role'] = 'customer';
            redirect('customer/');
        } else {
            $errors[] = "Email hoặc mật khẩu không đúng";
        }
    }
}

include 'header.php';
?>

<div class="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden mt-8">
    <div class="p-6">
        <h2 class="text-2xl font-bold text-center mb-6">Đăng nhập</h2>
        
        <?php if (!empty($errors)): ?>
            <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-6">
                <ul class="list-disc list-inside">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-4">
                <label for="email" class="block text-gray-700 font-medium mb-2">Email</label>
                <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500" required>
            </div>
            
            <div class="mb-6">
                <label for="password" class="block text-gray-700 font-medium mb-2">Mật khẩu</label>
                <input type="password" id="password" name="password" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500" required>
            </div>
            
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center">
                    <input type="checkbox" id="remember" name="remember" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                    <label for="remember" class="ml-2 block text-gray-700">Ghi nhớ đăng nhập</label>
                </div>
                
                <div>
                    <a href="forgot-password.php" class="text-indigo-600 hover:text-indigo-800">Quên mật khẩu?</a>
                </div>
            </div>
            
            <div class="mb-6">
                <button type="submit" class="w-full bg-indigo-600 text-white font-medium py-3 rounded-lg hover:bg-indigo-700 focus:outline-none">
                    Đăng nhập
                </button>
            </div>
        </form>
        
        <div class="text-center">
            <p class="text-gray-600">Chưa có tài khoản? <a href="register.php" class="text-indigo-600 hover:text-indigo-800">Đăng ký</a></p>
        </div>
        
        <!-- Demo accounts -->
        <div class="mt-8 pt-6 border-t border-gray-200">
            <h3 class="text-lg font-semibold mb-2">Tài khoản demo</h3>
            <div class="space-y-1 text-sm text-gray-600">
                <p><strong>Admin:</strong> admin@example.com / password</p>
                <p><strong>Driver:</strong> driver@example.com / password</p>
                <p><strong>Customer:</strong> customer@example.com / password</p>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 