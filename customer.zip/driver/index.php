<?php
// Include config file
require_once '../config.php';

// Nếu không đăng nhập hoặc không phải tài xế thì chuyển hướng về trang đăng nhập
if (!isLoggedIn() || !hasRole('driver')) {
    redirect('login.php');
}

// Include header
include '../header.php';
?>

<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6">Driver Dashboard</h1>
    
    <!-- Profile Section -->
    <div class="bg-white shadow-md rounded-lg mb-6">
        <div class="p-6">
            <h2 class="text-xl font-bold mb-4">Driver Profile</h2>
            <div class="flex items-center space-x-4">
                <div class="w-16 h-16 rounded-full bg-gray-200"></div>
                <div>
                    <h3 class="text-lg font-semibold">John Doe</h3>
                    <p class="text-gray-500">ID: DRV-001</p>
                    <span class="badge bg-green-600 text-white px-2 py-1 rounded text-xs">Available</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Current Delivery Section -->
    <div class="bg-white shadow-md rounded-lg mb-6">
        <div class="p-6">
            <h2 class="text-xl font-bold mb-4">Current Delivery</h2>
            <div class="space-y-4">
                <div class="flex justify-between items-center">
                    <div>
                        <h4 class="font-semibold">Order #12345</h4>
                        <p class="text-sm text-gray-500">123 Main St → 456 Elm St</p>
                    </div>
                    <span class="badge bg-indigo-600 text-white px-2 py-1 rounded text-xs">In Progress</span>
                </div>
                <div class="flex space-x-2">
                    <button class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded">
                        Start Delivery
                    </button>
                    <button class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-2 px-4 rounded">
                        View Details
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delivery History -->
    <div class="bg-white shadow-md rounded-lg">
        <div class="p-6">
            <h2 class="text-xl font-bold mb-4">Recent Deliveries</h2>
            <div class="space-y-4">
                <?php for ($i = 1; $i <= 3; $i++): ?>
                <div class="flex justify-between items-center border-b pb-2">
                    <div>
                        <h4 class="font-semibold">Order #<?php echo 12340 + $i; ?></h4>
                        <p class="text-sm text-gray-500">Completed on March <?php echo $i; ?>, 2024</p>
                    </div>
                    <span class="badge bg-gray-500 text-white px-2 py-1 rounded text-xs">Completed</span>
                </div>
                <?php endfor; ?>
            </div>
        </div>
    </div>
</div>

<?php include '../footer.php'; ?> 