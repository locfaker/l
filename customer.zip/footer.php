    </main>

    <!-- Footer -->
    <footer class="bg-white mt-12 py-6 shadow-inner">
        <div class="container mx-auto px-6">
            <div class="flex flex-wrap justify-between">
                <div class="w-full md:w-1/4 mb-6 md:mb-0">
                    <h5 class="text-xl font-bold mb-4">Dreamy Delivery</h5>
                    <p class="text-gray-600">Hệ thống giao hàng đáng tin cậy cho mọi nhu cầu của bạn.</p>
                </div>
                
                <div class="w-full md:w-1/4 mb-6 md:mb-0">
                    <h5 class="text-lg font-semibold mb-4">Liên kết</h5>
                    <ul class="space-y-2">
                        <li><a href="index.php" class="text-gray-600 hover:text-indigo-600">Trang chủ</a></li>
                        <li><a href="about.php" class="text-gray-600 hover:text-indigo-600">Giới thiệu</a></li>
                        <li><a href="services.php" class="text-gray-600 hover:text-indigo-600">Dịch vụ</a></li>
                        <li><a href="contact.php" class="text-gray-600 hover:text-indigo-600">Liên hệ</a></li>
                    </ul>
                </div>
                
                <div class="w-full md:w-1/4 mb-6 md:mb-0">
                    <h5 class="text-lg font-semibold mb-4">Cổng người dùng</h5>
                    <ul class="space-y-2">
                        <li><a href="customer/" class="text-gray-600 hover:text-indigo-600">Khách hàng</a></li>
                        <li><a href="driver/" class="text-gray-600 hover:text-indigo-600">Tài xế</a></li>
                        <li><a href="admin/" class="text-gray-600 hover:text-indigo-600">Quản trị viên</a></li>
                    </ul>
                </div>
                
                <div class="w-full md:w-1/4">
                    <h5 class="text-lg font-semibold mb-4">Liên hệ</h5>
                    <ul class="space-y-2">
                        <li class="flex items-start">
                            <i class="fas fa-map-marker-alt mt-1 mr-2 text-indigo-600"></i>
                            <span class="text-gray-600">123 Đường Nguyễn Văn Linh, Quận 7, TP.HCM</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-phone mr-2 text-indigo-600"></i>
                            <span class="text-gray-600">+84 987 654 321</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-envelope mr-2 text-indigo-600"></i>
                            <span class="text-gray-600">info@dreamydelivery.com</span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="border-t border-gray-200 mt-8 pt-6 text-center">
                <p class="text-gray-600">&copy; <?php echo date('Y'); ?> Dreamy Delivery. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script>
        // Toggle dropdown menu
        document.addEventListener('DOMContentLoaded', function() {
            const dropdownButton = document.querySelector('button.flex.items-center');
            const dropdownMenu = document.querySelector('.absolute.right-0.mt-2');
            
            if (dropdownButton && dropdownMenu) {
                dropdownButton.addEventListener('click', function() {
                    dropdownMenu.classList.toggle('hidden');
                });
                
                // Close when clicking outside
                document.addEventListener('click', function(event) {
                    if (!dropdownButton.contains(event.target) && !dropdownMenu.contains(event.target)) {
                        dropdownMenu.classList.add('hidden');
                    }
                });
            }
        });
    </script>
</body>
</html> 